#Team BaKa - San pham KidLine

### Stream API
1.lib: 
- socket.io
- expressjs 
- nodejs 
